<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
    <title>Document</title>
</head>
<body style="scroll-behavior:smooth;background-image: url('wp.jpg');">
  <header class="text-gray-600 body-font">
    <div class="container mx-auto flex flex-wrap p-5 flex-col md:flex-row items-center">
      <a class="flex title-font font-medium items-center text-gray-900 mb-4 md:mb-0">
        </svg>
        <span class="ml-3 text-xl">Todo List</span>
      </a>
      <nav class="md:ml-auto flex flex-wrap items-center text-base justify-center">
        <a href="home.php" class="mr-5 hover:text-gray-900">Home</a>
        <a href="aboutus.php"  class="mr-5 hover:text-gray-900">About us.</a>
      </nav>
    </div>
  </header>
    <section class="text-gray-600 body-font">
        <div class="container px-5 py-24 mx-auto">
          <div class="text-center mb-20">
            <h1 class="sm:text-3xl text-2xl font-medium text-center title-font text-gray-900 mb-4">About Us</h1>
            <p class="text-base leading-relaxed xl:w-2/4 lg:w-3/4 mx-auto">As its name implies, the To-do list on an article's talk page shows the list of improvements suggested for the article. It is created and formatted using the {{To do}} template. The list is maintained by editors, writers, reviewers or readers like you as a way to focus your collaborative efforts. As such, they represent a tentative consensus that helps improve the efficiency of the editing process.</p>
            <p class="text-base leading-relaxed xl:w-2/4 lg:w-3/4 mx-auto">To start a new to-do list:

                go to the talk page of the article
                edit it
                at the top of the edit box, enter {{to do}}
                save your edit : the talk page is now shown with an empty to-do listTo add a task to the to do list:

                click the "edit" link at the top of the to-do list
                you can now either:
                use the default template text by using "Task" fields as explained in Template:Tasks
                remove the default template text and simply enter "*" followed by the description of the task. Please begin with a verb such as "explain", "discuss", "justify" to clearly describe the task.
                enter an edit summary as needed, select "watch", and save your changes.
                you can now go back to the talk page to check your entry. If necessary, click the purge or refresh button to refresh it by copy the URL and paste it back, then clicking Enter.
                Similarly, to edit or remove a task from the to-do list:
                
                click the "edit" link at the top of the to-do list
                edit or remove the task in the edit box
                enter an edit summary as needed, select "watch", and save your changes
                you can now go back to the talk page to check your entry. If necessary, click the purge button to refresh it.
                To add an article to a "To do" sub-category:
                
                go to the talk page of the article: you see its to-do list
                click the "edit" link at the top of the to-do list
                add [[Category:To do,<sub-category>]] in the edit box, where you replace "sub-category" by the name of the sub-category in which you want to include the article
                enter an edit summary as needed and save your changes
                To mark an item as in progress:
                
                from the talk page of the article click the "edit" link on the to do list
                add ''In progress'' ~~~ to the end of desired item.
                save your edit</p>
          </div>
          
        </div>
      </section>
</body>
</html>